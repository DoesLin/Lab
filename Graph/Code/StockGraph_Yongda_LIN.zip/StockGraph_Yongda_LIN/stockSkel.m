function [ ] = stockSkel( actionName, fileName1, fileName2, fileName3 )

readSkel(actionName, fileName1, 1);
readSkel(actionName, fileName2, 2);
readSkel(actionName, fileName3, 3);
% readSkel(actionName, fileName4, 4);

end

